package Flat;
import java.io.IOException;
 



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
/**
 * Servlet implementation class login
 */
public class Addvh extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	ConectionDatabase con=new ConectionDatabase();
	 private String message;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String type = request.getParameter("type");
		String  type1= request.getParameter("type1");
		String number=request.getParameter("number");
		String photo=request.getParameter("photo");
		String color=request.getParameter("color");
	
		if(type.equals("NO") && type1==null)
		{
			message="Select Vheicle type";
		}
		if(type.equals("NO"))
		{
		
			type=type1;
		}
		if(type.equals("car")||type.equals("bike"))
		{
			if(number==null)
			{
			message="For Car And Bike Number Must Required";
	
			}	}
		if(color.length()>50)
		{
			message="length of color muct be less then 50";
		}
		
		
		
		if (!(message==null))
		{
		
			System.out.println("nullvh"+message);

		request.setAttribute("message",message);
		request.getRequestDispatcher("Addvh.jsp").forward(request, response);
		}
		else
		{	
			HttpSession session = request.getSession();
            String email=(String)session.getAttribute("email");
            String[] s = new String[]{email,type,number,photo,color};
			System.out.println(con.addvh(s));
			
			message="Record added succesfully "; 

			request.setAttribute("message",message);
                
            	request.getRequestDispatcher("/lookvh.jsp").forward(request, response);
            	message=null;
		}
		}
 
}

