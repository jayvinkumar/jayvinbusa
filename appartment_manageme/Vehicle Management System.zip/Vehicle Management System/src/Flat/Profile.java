package Flat;



	import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
	 

	 
	/**
	 * Servlet implementation class login
	 */
	public class Profile extends HttpServlet {
		
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		ConectionDatabase con=new ConectionDatabase();
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        HttpSession session=request.getSession(false);  
	        String email=(String)session.getAttribute("email");
	   List <String> l= con.selcettable(email);
	 
	 
	   
	  String info= "first_name :"+l.get(0)+"</br>";
		info=info+"last_name: "+l.get(1)+"</br>";
		info=info+"email: "+l.get(2)+"</br>";
		info=info+"birth_date: "+l.get(3)+"</br>"; 
		info=info+"flat_p_date: "+l.get(4)+"</br>";
		info=info+"profile_picture:"+  "<img src=images/"+l.get(6)+"width="+170+"px height="+170+"px>"+"</br>";
		info=info+"flat_block :"+l.get(6)+"</br>";
		info=info+"flat_number: "+l.get(7)+"</br>";
		info=info+"mobile: "+l.get(8)+"</br>";
	        	
	        request.setAttribute("profileinfo",info);
	        request.getRequestDispatcher("profile.jsp").forward(request, response);
	        		
	}
	}

