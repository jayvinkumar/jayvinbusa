package Flat;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.regex.Pattern;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;
import com.sun.org.apache.xerces.internal.impl.xs.identity.Selector.Matcher;
public class Validation extends HttpServlet
{
	 /**
	 * 
	 */
	ConectionDatabase con=new ConectionDatabase();
	
	private static final long serialVersionUID = 1L;
 
	 private String message;
	 String regex_password = "^(?=.*[0-9])"
             + "(?=.*[a-z])(?=.*[A-Z])"
             + "(?=.*[@#$%^&+=])"
             + "(?=\\S+$).{8,20}$";
	  //cheack email


	   public void doPost(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {
    
			String first_name = request.getParameter("first_name");
			String last_name = request.getParameter("last_name");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			String c_password = request.getParameter("c_password");
			String birth_date = request.getParameter("birth_date");
			String flat_p_date = request.getParameter("flat_p_date");
			String profile_picture = request.getParameter("profile_picture");
			String flat_block = request.getParameter("flat_block");
			String flat_number = request.getParameter("flat_number");
			String mobile = request.getParameter("mobile_number");
			String iagree = request.getParameter("iagree");
			
			
			int flat_nu=0;
			try{flat_nu=Integer.parseInt(flat_number);}catch(Exception e){message="Flat Number must be 1-20";}
			// cheack password
			Pattern p = Pattern.compile(regex_password);
			 java.util.regex.Matcher m = p.matcher(password);
			 
	
			 
			 Pattern.matches("^(.+)@(.+)$", email);
			 //cheack block number
			 //cheack flat number
			 
			
			if(first_name.isEmpty() || last_name.isEmpty() ||! ( Pattern.matches("[a-zA-Z]*",first_name))||! ( Pattern.matches("[a-zA-Z]*",first_name)) )
			{
				message=""+"firt name last name must contain laters\n";
			}
			if(password==null ||!(m.matches())  )
			{
				message=message+"paasword Required, At-least 1 Capital, At-least 1 number, At-least 1 special char\n";
			}
			if(!(password.equals(c_password)))
			{
				message=message+"confirm password must same as password\n";
			}
		if(!( Pattern.matches("^(.+)@(.+)$", email)))
			{
						message=message+"invalid email addrasss";
			}
		if((iagree=="on"))
		{
					message=message+"must agree with term";
		}
		if(!( Pattern.matches("[A-F]{1}", flat_block)))
		{
			message=message+"Block number not empty and between A-E";
		}
		if( flat_nu>20 )
		{
			message=message+"flat_number number not empty and between 1-20";
		}
		if(con.duplicateChack(email)==500)
		{
			message=message+"Email allready exit";
		}
if(message==null)
{
	
	 String[] s = new String[]{first_name, last_name, email, password, c_password, birth_date, flat_p_date, profile_picture, flat_block, flat_number,mobile};
	 
	 int i=con.insertotable(s);
	System.out.println("row updated  "+i);
	message="sigup succsess please login";
	request.setAttribute("message",message);
	request.getRequestDispatcher("Login.jsp").forward(request, response);
}
else
{
request.setAttribute("message",message);
request.getRequestDispatcher("signup.jsp").forward(request, response);
}


	   }

	   public void destroy() {
	      // do nothing.
	   }
}