package Flat;
import java.io.IOException;
 



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
/**
 * Servlet implementation class login
 */
public class Updatevh extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	ConectionDatabase con=new ConectionDatabase();
	 private String message;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String  type1= request.getParameter("type1");
		String number=request.getParameter("number");
		String photo=request.getParameter("photo");
		String color=request.getParameter("color");
		
		if(type1==null)
		{
			message="Select Vheicle type";
		}
		if(type1=="car"||type1=="bike")
		{
			if(number==null)
			{
			message="For Car And Bike Number Must Required";
	
			}	}
		if(color.length()>50)
		{
			message="length of color muct be less then 50";
		}
		
		
		
		if (!(message==null))
		{
		
		request.setAttribute("message",message);
		request.getRequestDispatcher("lookvh.jsp").forward(request, response);
		}
		else
		{
			HttpSession session = request.getSession();
            String id=String.valueOf(session.getAttribute("id"));
            
            String[] s = new String[]{id,type1,number,photo,color};
			System.out.println(con.updatevh(s));
			
			message="Record update succesfully "; 

			request.setAttribute("message",message);
                
            	request.getRequestDispatcher("/lookvh.jsp").forward(request, response);
		}
		}
 
}

