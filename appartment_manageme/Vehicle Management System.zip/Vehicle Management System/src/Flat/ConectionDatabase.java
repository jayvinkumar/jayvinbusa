package Flat;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 public class ConectionDatabase {

	
	 public  int insertotable(String s[]){  
		 try{ 
			 
			 Class.forName("com.mysql.jdbc.Driver");  
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
			
			 String insert="INSERT INTO tenants ( first_name, last_name, email, password, c_password, birth_date, flat_p_date, profile_picture, flat_block, flat_number,mobile) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
				
			 PreparedStatement ps=con.prepareStatement(insert);  
		 
		
			ps.setString(1,s[0]);  
			ps.setString(2,s[1]);  
			
			ps.setString(3,s[2]);  
			
			ps.setString(4,s[3]);  
			
			ps.setString(5,s[4]);  
		
			ps.setString(6,s[5]);  
			
			ps.setString(7,s[6]);  
		
			ps.setString(8,s[7]);  
			
			ps.setString(9,s[8]);  
			ps.setString(10,s[9]); 
			ps.setString(11,s[10]);
		int i= ps.executeUpdate();  
		 
		 con.close();  
		return i;
		 }
		 catch(Exception e){
			 
			 System.out.println(e);} 
		 
		return 500;
		 }  
		
	 public  String selectpassword(String username,String password){  
		 try{ 
			 
			 Class.forName("com.mysql.jdbc.Driver");  
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
			
			 String email="";
			 String password1="";
			 String name="";
			 
			 String select="SELECT email,password,first_name FROM `tenants` WHERE email= ?";
			
			 PreparedStatement ps=con.prepareStatement(select);  
		      ps.setString(1,username); 
			 
			 ResultSet rs=ps.executeQuery();  
			 while(rs.next()){  
			 email=rs.getString(1) ;
			 password1=rs.getString(2); 
			 name=rs.getString(3);
			 }
			 
		
			 if(email.equals(username) && password1.equals(password))
			 {
				 

				 return name;
			 }
			    
		 con.close();  
		
		 }
		 catch(Exception e){
			 
			 System.out.println(e);
			
		 }
		 
		 System.out.println("out of if");
	
return null;
		 }  
	 public  int duplicateChack(String username){  
		 try{ 
			 
			 Class.forName("com.mysql.jdbc.Driver");  
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
			
		
			 
			 String select="SELECT * From `tenants` WHERE email ='"+username+"'";
		        Statement st=con.createStatement();
				 ResultSet rs=st.executeQuery(select); 
				 String email="";
			 while(rs.next()){  
				 email=rs.getString("email") ;
	}
	if(email.equals(username))		 
	{
		return 500;
	}
			 
		 con.close();  
		
		 }
		 catch(Exception e){
			 
			 System.out.println(e);
			
		 }
		 

	
return 1;
		 }  	
	 public  String resetpassword(String username,String mobile){  
		 try{ 
			 
			 Class.forName("com.mysql.jdbc.Driver");  
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
			 String mobile1="";
			 String email="";
			 String password1="";
			 
			 String select="SELECT email,mobile,password FROM `tenants` WHERE email= ?";
			
			 PreparedStatement ps=con.prepareStatement(select);  
		      ps.setString(1,username); 
			 
			 ResultSet rs=ps.executeQuery();  
			 while(rs.next()){  
			 email=rs.getString(1) ;
			 mobile1=rs.getString(2); 
			 password1=rs.getString(3); 
			 }    	
			 
			 if(email.equals(username) && mobile.equals(mobile1))
			 {
				 return password1;
			 }
			    
		 con.close();  
		
		 }
		 catch(Exception e){
			 
			 System.out.println(e);
			 return null;
		 }
		 
return null;
		 }  
		
public List <String>selcettable(String username) 
{
	try{
	Class.forName("com.mysql.jdbc.Driver");  
	 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
	List<String> l=new ArrayList<String>();
	 
	 String select="SELECT * FROM `tenants` WHERE email= ?";
	
	 PreparedStatement ps=con.prepareStatement(select);  
     ps.setString(1,username); 
	 System.out.println("Connection "+username);

	 ResultSet rs=ps.executeQuery();  
	
	 while(rs.next()){
			
	l.add(String.valueOf(rs.getInt("id")));
	l.add(rs.getString("first_name")); 
	
	l.add(rs.getString("last_name")); 
	l.add(rs.getString("email")) ;
	l.add(rs.getString("birth_date")); 
	l.add(rs.getString("flat_p_date")); 
	l.add(rs.getString("profile_picture") );
	l.add(rs.getString("flat_block")); 
	l.add(rs.getString("flat_number")); 
	l.add(rs.getString("mobile")); 
	
	 }
	 System.out.println(l);
	
	 return l;
}
	catch(Exception e)
	{
		System.out.println(e);
		System.out.println("catch");
		return null;
	}
}

public  ResultSet selectallVh(){  
	 try{ 
		 
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		 
		 
		 String select="SELECT * FROM `Vehicle`";
		
		 Statement statement = con.createStatement() ;
         ResultSet resultset = statement.executeQuery(select) ;
		    	
		 
		
			 return resultset;
	
	 }
	 catch(Exception e){
		 
		 System.out.println(e);
		 return null;
	 }
	
	 }  
public  ResultSet selectVhType(){  
	 try{ 
		 
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		 
		 
		 String select="SELECT DISTINCT type FROM `Vehicle`";
		
		 Statement statement = con.createStatement() ;
        ResultSet resultset = statement.executeQuery(select) ;
		    	
		 
		
			 return resultset;
	
	 }
	 catch(Exception e){
		 
		 System.out.println(e);
		 return null;
	 }
	
	 }  

public  int addvh(String s[]){  
	 try{ 
		 
		 int id=0;
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		 String select="SELECT id FROM `tenants` WHERE email= ?";
			
		 PreparedStatement ps=con.prepareStatement(select);  
	     ps.setString(1,s[0]); 
	     ResultSet rs=ps.executeQuery();  
	 
		 while(rs.next()){id=rs.getInt("id");}
		 
		 String insert="INSERT INTO  Vehicle( type, number, photo, color,person_id) VALUES (?,?,?,?,?)";
		 PreparedStatement ps1=con.prepareStatement(insert); 
		
	 
	
		ps1.setString(1,s[1]);  
		ps1.setString(2,s[2]);  
		
		ps1.setString(3,s[3]);  
		
		ps1.setString(4,s[4]);  
		
		ps1.setInt(5,id);  
	
		int i= ps1.executeUpdate();  
		System.out.println("id is"+id);
	 con.close();  
	return i;
	 }
	 catch(Exception e){
		 
		 System.out.println(e);} 
	 
	return 500;
	 }  
public  ResultSet lookVh(String email){  
	 try{ 
		 int id=0;
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		 String select="SELECT id FROM `tenants` WHERE email= ?";
			
		 PreparedStatement ps=con.prepareStatement(select);  
	     ps.setString(1,email); 
	     ResultSet rs=ps.executeQuery();  
	 
		 while(rs.next())
		 {id=rs.getInt("id");}
		 
		 String select1="SELECT * FROM `Vehicle`WHERE person_id=? ";
		
		 PreparedStatement ps1=con.prepareStatement(select1);  
	     ps1.setInt(1,id); 
	     ResultSet rs2=ps1.executeQuery(); 
		    	
		 
		
			 return rs2;
	
	 }
	 catch(Exception e){
		 
		 System.out.println(e);
		 return null;
	 }
	
	 }  
public int  updatevh(String s[])
{
	try{ 
		 
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		 int id=Integer.parseInt(s[0]);
		 String select="select id FROM vehicle WHERE person_id="+id;
		 Statement st1=con.createStatement();
		
		 ResultSet rs=st1.executeQuery(select);
		 
		 while(rs.next())
		 {id=rs.getInt("id");}		    	
        String select1="Update vehicle set type=?,number=?,photo=?,color=? where id="+id;
		
		 PreparedStatement ps1=con.prepareStatement(select1);  
		
		 ps1.setString(1, s[1]);
		 ps1.setString(2, s[2]);
		 ps1.setString(3,s[3] );
		 ps1.setString(4, s[4]);
		 int i = ps1.executeUpdate();
	System.out.println("id in coneection"+i);
			 return i;
	
	 }
	 catch(Exception e){
		 System.out.println("id in coneection catch"+500);

		 System.out.println(e);
		 return 500;
	 }

}
public int  delvh(String s)
{
	try{ 
		 
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		 int id=Integer.parseInt(s);
		 String select1="select id FROM vehicle WHERE person_id="+id;
		 Statement st1=con.createStatement();
		
		 ResultSet rs=st1.executeQuery(select1);
		 
		 while(rs.next())
		 {id=rs.getInt("id");}
		 
        String select="DELETE FROM vehicle WHERE id="+id;
		 Statement st=con.createStatement();
		 int i=st.executeUpdate(select);
		 
		 return i;
	
	 }
	 catch(Exception e){
		 
		 System.out.println(e);
		 return 500;
	 }

}
public ResultSet  searchBytype(String s)
{
	try{ 
		 
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		String id=s;
		 		    	
        String select="SELECT * from vehicle WHERE type='"+id+"'";
		 Statement st=con.createStatement();
		 ResultSet rs=st.executeQuery(select); 
	    	
		 
			
		 return rs;
		 
		 
	
	 }
	 catch(Exception e){
		 
		 System.out.println(e);
		 return null;
	 }

}

public ResultSet  searchByNumber(String s)
{
	try{ 
		 
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
             
		 		    	
        String select="SELECT * from vehicle WHERE number='"+s+"'";
		
		 
		 Statement st=con.createStatement();
		 ResultSet rs=st.executeQuery(select); 
	    	
		 
			
		 return rs;
	
	 }
	 catch(Exception e){
		 
		 System.out.println(e);
		 return null;
	 }

}

public ResultSet  searchByPersonname(String s)
{
	try{ 
		 
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
		
		 		    	int id=0;
        String select="SELECT id FROM  tenants WHERE first_name='"+s+"'";
        Statement st=con.createStatement();
		 ResultSet rs=st.executeQuery(select); 
	    	while(rs.next())
	    	{
	    		id=rs.getInt("id");
	    	}
	    	
	    	  String select1="SELECT * FROM  vehicle WHERE person_id="+id;
	          Statement st1=con.createStatement();
	  		 ResultSet rs1=st.executeQuery(select1); 
	  		
		 return rs1;	
	 }
	 catch(Exception e){
		 
		 System.out.println(e);
		 return null;
	 }
}
	public ResultSet  searchByBlock(String s)
	{
		try{ 
			 
			 Class.forName("com.mysql.jdbc.Driver");  
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
			 int id=0;
		        String select="SELECT id FROM  tenants WHERE flat_block='"+s+"'";
		        Statement st=con.createStatement();
				 ResultSet rs=st.executeQuery(select); 
			    	while(rs.next())
			    	{
			    		id=rs.getInt("id");
			    	}
			    	  String select1="SELECT * FROM  vehicle WHERE person_id="+id;
			          Statement st1=con.createStatement();
			  		 ResultSet rs1=st.executeQuery(select1); 
					
				 return rs1;	
		
		 }
		 catch(Exception e){
			 
			 System.out.println(e);
			 return null;
		 }

	}
	public ResultSet  searchFlateNumber(String s)
	{
		try{ 
			 
			 Class.forName("com.mysql.jdbc.Driver");  
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/appartement","root","");  
			 int id=0;
		        String select="SELECT id FROM  tenants WHERE flat_number='"+s+"'";
		        Statement st=con.createStatement();
				 ResultSet rs=st.executeQuery(select); 
			    	while(rs.next())
			    	{
			    		id=rs.getInt("id");
			    	}
			    	  String select1="SELECT * FROM  vehicle WHERE person_id="+id;
			          Statement st1=con.createStatement();
			  		 ResultSet rs1=st.executeQuery(select1); 
					
				 return rs1;	
		
		 }
		 catch(Exception e){
			 
			 System.out.println(e);
			 return null;
		 }

	}

}




