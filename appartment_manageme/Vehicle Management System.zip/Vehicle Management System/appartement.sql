-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2021 at 07:36 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appartement`
--

-- --------------------------------------------------------

--
-- Table structure for table `ta`
--

CREATE TABLE `ta` (
  `id` int(20) NOT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ta`
--

INSERT INTO `ta` (`id`, `name`) VALUES
(1, 'fdsfgt'),
(2, 'fdsfgt'),
(3, '101');

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `id` int(20) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `c_password` varchar(20) NOT NULL,
  `birth_date` varchar(20) DEFAULT NULL,
  `flat_p_date` varchar(20) DEFAULT NULL,
  `profile_picture` varchar(200) DEFAULT NULL,
  `flat_block` varchar(20) DEFAULT NULL,
  `flat_number` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`id`, `first_name`, `last_name`, `email`, `password`, `c_password`, `birth_date`, `flat_p_date`, `profile_picture`, `flat_block`, `flat_number`, `mobile`) VALUES
(15, 'Sahajanand', 'ten', 'jayvin.busa1@gmail.com', '12332145@Jb', '12332145@Jb', '0000-00-00', '0000-00-00', '', '', '', '123'),
(16, 'Sahajanand', 'ten', 'or@gmail.com', '12332145@Jb', '12332145@Jb', '2021-05-29', '2021-05-29', 'slide-2.jpg', 'A', '12', '07990682103'),
(17, 'alex', 'ten', 'alexten@gmail.com', 'Kaka@123', 'Kaka@123', '2021-05-29', '2021-05-29', 'A:/java/Vehicle Mana', 'A', '10', '98985524248'),
(18, 'maru', 'gujrat', 'Maru@123.com', 'Maru@123', 'Maru@123', '2021-05-29', '2021-05-14', 'A:/java/Vehicle Mana', 'A', '12', '15153030'),
(19, 'Sahajanand', 'ten', 'Maru@123.com', 'Maru@123', 'Maru@123', '2021-05-29', '2021-05-12', 'A:/java/Vehicle Management System/build/image/Dr.FarFar-Logo.png', 'A', '12', '9855521956'),
(20, 'Sahajanand', 'ten', 'Maru@123.com', 'Maru@123', 'Maru@123', '2021-05-13', '2021-05-06', 'A:/java/Vehicle Management System/build/image/Dr.FarFar-Logo.png', 'A', '12', '07990682103'),
(21, 'Sahajanand', 'ten', 'Maru@123.com', 'Maru@123', 'Maru@123', '2021-05-13', '2021-05-13', 'A:/java/Vehicle Management System/build/image/Dr.FarFar-Logo.png', 'A', '12', '9855521956');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `type` varchar(20) NOT NULL,
  `number` varchar(20) NOT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `color` varchar(20) NOT NULL,
  `id` int(20) NOT NULL,
  `person_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`type`, `number`, `photo`, `color`, `id`, `person_id`) VALUES
('car', 'patel', 'Dr.FarFar-Logo.png', 'white', 19, 21);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ta`
--
ALTER TABLE `ta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ta`
--
ALTER TABLE `ta`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tenants`
--
ALTER TABLE `tenants`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
