package Flat;



import java.io.IOException;
 


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
/**
 * Servlet implementation class login
 */
public class Fpassword extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String username;
	String mobile;
	ConectionDatabase con=new ConectionDatabase();
	 private String message;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.username = request.getParameter("username");
		this.mobile = request.getParameter("mobile");
		
		if(username== null|| mobile==null )
		{
			message="email and mobile is not be empty";
		}
		if(con.resetpassword(username,mobile)==null)
		{
			message="email and mobile not match";
		}
		
		
		
		if (!(message==null))
		{

		request.setAttribute("message",message);
		request.getRequestDispatcher("fpassword.jsp").forward(request, response);
		}
		else
		{
			
			message="your temprary passwor is  " + con.resetpassword(username,mobile);
			request.setAttribute("message",message);
            	request.getRequestDispatcher("Login.jsp").forward(request, response);
		}
		}
 
}


