package Flat;



	import java.io.IOException;
	 


	import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
	 
	/**
	 * Servlet implementation class login
	 */
	public class Login extends HttpServlet {
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		String username;
		String password;
		ConectionDatabase con=new ConectionDatabase();
		 private String message;
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			this.username = request.getParameter("username");
			this.password = request.getParameter("password");
			
			if(username.isEmpty() || password.isEmpty() )
			{
				message="username and password not be empty";
			}
			if(con.selectpassword(username,password)==null)
			{
				message="username and password incorrect";
			}
			
			
			
			if (!(message==null))
			{
			System.out.println("yo boy come under null messgae");
			request.setAttribute("message",message);
			request.getRequestDispatcher("Login.jsp").forward(request, response);
			}
			else
			{
				
				message="welcome  " + con.selectpassword(username,password);
				 HttpSession session = request.getSession();
	                session.setAttribute("message",message );
	                session.setAttribute("email", username);
	                
	            	request.getRequestDispatcher("/profile.jsp").forward(request, response);
			}
			}
	 
	}

