package Flat;


	 
	import java.io.IOException;
	 
	import javax.servlet.*;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.*;
	 

	public class Logout extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	 
	    public Logout() {
	        super();
	    }
	 
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        HttpSession session = request.getSession(false);
	        
	        if (session != null) {
	        	System.out.println("under if of logout");
	            session.removeAttribute("message");
	            session.removeAttribute("email");
	            session.removeAttribute("id");
	           RequestDispatcher dispatcher = request.getRequestDispatcher("Login.jsp");
	            dispatcher.forward(request, response);
	        }
	    }
	}
